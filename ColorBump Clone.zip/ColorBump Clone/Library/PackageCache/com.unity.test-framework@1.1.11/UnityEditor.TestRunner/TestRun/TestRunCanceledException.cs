using System;

namespace UnityEditor.TestTools.TestRunner.TestRun
{
    internal class TestRunCanceledException : Exception
    {
        
    }
}