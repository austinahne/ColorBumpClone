﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager singleton;
    public bool GameStarted { get; private set; }
    public bool GameEnded { get; private set; }

    [SerializeField] private float slowMoFactor = .1f;//for slow motion, sets at 10% of normal time
    [SerializeField] private Transform startTransform;//start position
    [SerializeField] private Transform goalTransform;//end position
    [SerializeField] private BallController ball;//to check where the ball is
    
    public float EntireDistance { get; private set; }
    public float DistanceLeft { get; private set; }

    private void Start()
    {
        StartGame();
        EntireDistance = goalTransform.position.z - startTransform.position.z;//calculates distance
    }

    // Start is called before the first frame update
    private void Awake()
    {
        if(singleton == null)
        {
            singleton = this;
        }else if(singleton != this)
        {
            Destroy(gameObject);
        }

        //time control
        Time.timeScale = 1f; //scale at which time is passing
        Time.fixedDeltaTime = .02f; //interval in seconds at which physics and other fixed framerate updates occur
    }

 

    public void StartGame()
    {
        GameStarted = true;
        Debug.Log("Game Started");
    }

    public void EndGame(bool win)
    {
        GameEnded = true;
        Debug.Log("Game Ended");

        //if you hit an obstacle/lost game
        if(!win)
        {
            //Restarts the game by calling RestartGame after 2 seconds have passed
            Invoke("RestartGame", 2 * slowMoFactor);//slowMo multiplied here so user doesnt have 
                                                    //to wait 20 seconds bc of timeScale change
            //slow motion
            Time.timeScale = slowMoFactor;
            Time.fixedDeltaTime = 0.02f * Time.timeScale;
        }
        else
        {
            //crosses finish line, moves to next level
            Invoke("NextLevel", 2);
        }
    }

    public void RestartGame()
    {
        //upon collision, reloads current scene
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex); //UnityEngine.SceneManagement.SceneManager.LoadScene(0);
    }

    public void NextLevel()
    {
        //upon crossing finish line, load next scene in scene build queue
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    // Update is called once per frame
    void Update()
    {
        //calculate how farther to go
        DistanceLeft = Vector3.Distance(ball.transform.position, goalTransform.position);

        
        if (DistanceLeft > EntireDistance)
            DistanceLeft = EntireDistance;

        if (ball.transform.position.z > goalTransform.transform.position.z)
            DistanceLeft = 0;

        Debug.Log("Distance traveled: " + DistanceLeft + "\nEntire Distance: " + EntireDistance);
    }
}
