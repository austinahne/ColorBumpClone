﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
    [SerializeField] private float thrust = 150f;//influences speed of the ball
    [SerializeField] private Rigidbody rb;//takes care of applying the physics
    [SerializeField] private float wallDistance = 5f; //distance from center to wall
    [SerializeField] private float minCamDistance = 3f; //minimum distance for camera to be behind ball

    private Vector2 lastMousePos;//must be stored outside update method so it stays static

    // Update is called once per frame
    void Update()
    {
        Vector2 deltaPos = Vector2.zero;//initialize vector for positional changes

        //if game has ended, don't accept any movement input
        if (GameManager.singleton.GameEnded)
            return;
        //mouse/finger tracking
        //since this is on android, it'll pick up your finger instead of mouse
        if (Input.GetMouseButton(0))
        {
            Vector2 currentMousePos = Input.mousePosition;

            if (lastMousePos == Vector2.zero)
                lastMousePos = currentMousePos;

            deltaPos = currentMousePos - lastMousePos;//difference between position you were before and now
            lastMousePos = currentMousePos;//new position will be last position

            Vector3 force = new Vector3(deltaPos.x, 0, deltaPos.y) * thrust;//deltas used to apply force in the right direction
            rb.AddForce(force);//moves the ball
        }
        else
        {
            lastMousePos = Vector2.zero;//use middle of the screen as a basis when there's no mouse input
        }
    }

    private void FixedUpdate()
    {
        if (GameManager.singleton.GameEnded)
            return;

        if(GameManager.singleton.GameStarted)
        {
            rb.MovePosition(transform.position + Vector3.forward * 5 * Time.fixedDeltaTime);
        }
    }

    //LateUpdate ideal for whatever has to be calculated after start
    private void LateUpdate()
    {
        Vector3 pos = transform.position;

        //keeps ball from falling off the track
        if(transform.position.x < -wallDistance)//checks if x position of the ball less than wall position
        {
            pos.x = -wallDistance;
        }else if(transform.position.x > wallDistance)
        {
            pos.x = wallDistance;
        }

        //makes it so ball cannot get behind camera
        if(transform.position.z < Camera.main.transform.position.z + minCamDistance)
        {
            pos.z = Camera.main.transform.position.z + minCamDistance;
        }

        transform.position = pos;
    }

    //method uses GameManager class, determines state of game based on set values
    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log(collision.ToString());

        if (GameManager.singleton.GameEnded)
            return;
        
        //check if element the ball is touching is tagged for death
        if (collision.gameObject.tag == "Death")
            GameManager.singleton.EndGame(false); //uses GameManager class
    }
}
