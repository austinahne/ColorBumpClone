﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        //if the object we had the collision with WAS ACTUALLY the ball
        BallController ball = other.GetComponent<BallController>();

        //if it's not the ball or game isn't running, do nothing
        if (!ball || GameManager.singleton.GameEnded)
            return;

        Debug.Log("Crossed the Goal!");

        GameManager.singleton.EndGame(true);
    }
}
