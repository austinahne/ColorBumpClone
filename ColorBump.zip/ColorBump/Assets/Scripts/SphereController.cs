﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField] private float thrust = 150f;//influences speed of the ball
    [SerializeField] private Rigidbody rb;//takes care of applying the physics
    
    // Update is called once per frame
    void Update()
    {

    }
}
